%==========================================================================
% This code is used to cut the images into many pieces for training and
% testing.
%-------------------------------------------------------------------------
% Author:Lipeng Xie
% Date:2017-03-20
%==========================================================================

addpath ./imgprocess_tools/
addpath ./loaddata/
%% set parameters
original_datapath = './data/original_data/';
datapath = './data/';
if ~exist(datapath,'dir')
    mkdir(datapath);
end
num_DB = 1; %number of databases
trainingfolder = 'training-set'; %fold name of samples 
testingfolder = 'testing-set';
%----------------images augmentation parameters------------------
para_imgaug.maxnum = 1;
para_imgaug.cropsize = 224; %size of the pathces
para_imgaug.random_fliplr = true;
para_imgaug.random_flipup = true;
para_imgaug.random_dropout = false; % drop rate 0~1
para_imgaug.save_format = '.png';

for k=1:num_DB 
    save_to_dir = [datapath trainingfolder '_' int2str(k) '/'];
    if ~exist(save_to_dir,'dir')
        mkdir(save_to_dir);
    end
    save_to_dir_img = [datapath testingfolder '_' int2str(k) '/'];
    if ~exist(save_to_dir_img,'dir')
        mkdir(save_to_dir_img);
    end
    files = dir([original_datapath '*_seg.nii.gz']);
    OriginImgNames = unique(arrayfun(@(x) x{1}{1},arrayfun(@(x) regexp(x.name,'_', 'split'),files,'UniformOutput',0),'UniformOutput',0));
    indices = crossvalind('Kfold',length(OriginImgNames),10);
    parfor i=1:length(OriginImgNames)
        %% load image mask
        mask_nifti_struct  = load_untouch_nii_gz([original_datapath OriginImgNames{i} '_seg' '.nii.gz']);
        maskdata = mask_nifti_struct.img;
         %% load image data
        Img_nifti_struct  = load_untouch_nii_gz([original_datapath OriginImgNames{i} '.nii.gz']);
        Imgdata = Img_nifti_struct.img; 
        Imgshape = size(Imgdata);
        if indices(i)<=6
            Flag_train = true;
            split_image = 3;
            split_time = 1;
        else
            copyfile([original_datapath OriginImgNames{i} '_seg' '.nii.gz'], save_to_dir_img);
            copyfile([original_datapath OriginImgNames{i} '.nii.gz'], save_to_dir_img);
            split_image = 1;
            split_time = 1;
            Flag_train = false;
        end
        %% time loop
       for j=1:Imgshape(4)
           %% laynum loop
           if mod(j,split_time)~=0 
               continue;
           end
           for m=1:Imgshape(3)
               mask = maskdata(:,:,m,j);
               [H,W] = size(mask);
               if mod(m,split_image)~=0 || sum(mask(:))<=0 || H<para_imgaug.cropsize || W<para_imgaug.cropsize
                   continue;
               end
               save_prefix = [OriginImgNames{i}  '_' num2str(m) '_' num2str(j)];
               Img = uint8(MinMax_Norm(Imgdata(:,:,m,j)));
               if Flag_train
                   ImageDataGenerator_withmask(Img,mask,save_prefix,save_to_dir,para_imgaug);
               else
                   imwrite(Img,[save_to_dir_img save_prefix '.png']);
                   mask = mask>0;
                   imwrite(mask,[save_to_dir_img save_prefix '_mask.png']);
                   Img_mixed_mask = putcoloron_img(Img,mask);
                   imwrite(Img_mixed_mask,[save_to_dir_img save_prefix '_mixed.png']);
               end
           end
       end
   end    

end






