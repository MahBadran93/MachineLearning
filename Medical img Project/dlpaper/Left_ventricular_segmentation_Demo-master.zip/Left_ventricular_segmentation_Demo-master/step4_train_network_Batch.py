# -*- coding: utf-8 -*-
"""
Created on Wed Jan 24 15:28:59 2018

@author: dlwork
"""

import numpy as np
from utils.write_read_tfrecord import *
import tensorflow as tf
import tensorlayer as tl
import time
from nets.construct_model import *
import os
import matplotlib.pyplot as plt


def Dice(G,S):
    GS_Inter = G & S
    GS_Inter = np.sum(GS_Inter,1)
    GS_Inter = np.sum(GS_Inter,1)
    G = np.sum(G,1)
    G = np.sum(G,1)
    S = np.sum(S,1)
    S = np.sum(S,1)
    iou = 2*GS_Inter/(G+S)
    iou=np.mean(iou)
    
    return iou
 
def Jaccard(G,S):
    GS_Inter = G & S
    GS_Inter = np.sum(GS_Inter,1)
    GS_Inter = np.sum(GS_Inter,1)
    G = np.sum(G,1)
    G = np.sum(G,1)
    S = np.sum(S,1)
    S = np.sum(S,1)
    iou = GS_Inter/(G+S-GS_Inter)
    iou=np.mean(iou)
    
    return iou       
#=========================step1: Set parameters===============================
datapath = './data/'  #the path to store patches and lmdb

npatches = 1
nfolds = 1
batch_size = 8
#patchpathlist = glob.glob(datapath+'patches_'+'*')
option_resume = False # load model, resume from previous checkpoint?
option_savenet = True
data_shape = [224,224,1]

train_tfrecord = './data/train_1_1.tfrecords'
valid_tfrecord = './data/valid_1_1.tfrecords'
mean_file_name = './data/train_1_1.tfrecords_mean.npy'
is_train = True
reuse = False
trainnum = sum(1 for _ in tf.python_io.tf_record_iterator(train_tfrecord)) 
validnum = sum(1 for _ in tf.python_io.tf_record_iterator(valid_tfrecord)) 

min_after_dequeue_train = trainnum
capacity_train = min_after_dequeue_train + 3 * batch_size
capacity_test = validnum + 3 * batch_size

# train
n_epoch = 300
n_step_epoch = int(trainnum/batch_size)
n_step = n_epoch * n_step_epoch

learning_rate = 0.00001
print_freq = 20

Network_List = ['Hed']#'Fcn8s','Hed','Unet','Unet_PW','Proposed_Without_PW','Proposed'
#=========================step2: Load Dat====a================================
train_img, train_label = read_and_decode(train_tfrecord,data_shape)      
X_train, y_train = tf.train.shuffle_batch([train_img, train_label],
                                                batch_size=batch_size, capacity=1000,
                                                min_after_dequeue=500)

valid_img, valid_label = read_and_decode(valid_tfrecord,data_shape)      
X_valid, y_valid = tf.train.batch([valid_img, valid_label],
                                                batch_size=batch_size, capacity=100)
#=========================step3: Creat network===============================
x = tf.placeholder(tf.float32, shape=[batch_size, data_shape[0],data_shape[1], 1])   # [batch_size, height, width, channels]
y_ = tf.placeholder(tf.float32, shape=[batch_size,data_shape[0],data_shape[1], 2])
                   
#=========================step4: Train network===============================

for netname in Network_List:
    model_path = './checkpoints/'+netname+'/'
    if not os.path.exists(model_path):
        os.mkdir(model_path)        
    model_file_name = model_path + "model_tfrecord.ckpt"
    
    if netname=='Proposed' or netname=='Proposed_Without_PW' or netname=='Unet_PW':
        exec('network,cost,op_class1 = model_'+netname+'(x, y_, batch_size, data_shape, reuse=reuse, mean_file_name=mean_file_name,is_train = is_train)')
        exec('_,op_class_valid,_ = model_'+netname+'(x, y_, batch_size, data_shape,reuse=True,mean_file_name=mean_file_name, is_train = False)')
    else:        
        exec('network,cost,op_class1 = model_'+netname+'(x,y_,batch_size,reuse=reuse,mean_file_name=mean_file_name, is_train = is_train)')
        exec('_,op_class_valid,_ = model_'+netname+'(x,y_,batch_size,reuse=True,mean_file_name=mean_file_name, is_train = False)')
      
    train_params = network.all_params
    train_op = tf.train.AdamOptimizer(learning_rate, beta1=0.9, beta2=0.999,
    epsilon=1e-08, use_locking=False).minimize(cost, var_list=train_params)
    #

    sess = tf.Session()
    init=tf.global_variables_initializer()  
    sess.run(init)
    
    if option_resume:
        print("Load existing model " + "!"*10)
        saver = tf.train.Saver(network.all_params)
        saver.restore(sess, model_file_name)
    
    
    
    coord = tf.train.Coordinator() #stop thread
    threads = tf.train.start_queue_runners(sess=sess,coord=coord)
    step = 0
    iterrecord = []
    trainaccrecord = []
    validaccrecord = []
    for epoch in range(n_epoch):
        start_time = time.time()
        train_acc, train_loss,  n_batch = 0, 0, 0
        for s in range(n_step_epoch):
            X_train_a, y_train_a = sess.run([X_train, y_train])
            feed_dict = {x: X_train_a, y_: y_train_a}
            feed_dict.update(network.all_drop)   # enable noise layers
            _, err, output_class_train= sess.run([train_op,cost,op_class1], feed_dict=feed_dict)
            output_class = output_class_train[:,:,:,0]>0
            step += 1; train_acc += Dice(y_train_a[:,:,:,1]>0,output_class); train_loss += err; n_batch += 1
            
        if epoch + 1 == 1 or (epoch + 1) % print_freq == 0:
            print("Epoch %d : Step %d-%d of %d took %fs" % (epoch, step, step + n_step_epoch, n_step, time.time() - start_time))
            print("   train loss: %f" % (train_loss/ n_batch))
            print("   train Dice acc: %f" % (train_acc/ n_batch))
            iterrecord.append(epoch)
            trainaccrecord.append(train_acc/ n_batch)
            tl.visualize.images2d(images=output_class_train, second=0, saveable=True, name=netname+'_images1_'+str(epoch), dtype=None, fig_idx=3119362)
            #==================test=========================
            valid_acc, n_batch = 0, 0
            for _ in range(int(validnum/batch_size)):
                X_valid_a, y_valid_a= sess.run([X_valid, y_valid])
                feed_dict = {x: X_valid_a, y_: y_valid_a}
                output_class_valid  = sess.run(op_class_valid, feed_dict=feed_dict)
                output_class = output_class_valid[:,:,:,0]>0
                valid_acc += Dice(y_valid_a[:,:,:,1]>0,output_class); n_batch += 1

            print("   Valid Dice acc: %f" % (valid_acc/ n_batch))        
            if option_savenet:
                print("Save model " + "!"*10)
                saver = tf.train.Saver()
                saver.save(sess, model_path+"model_tfrecord_"+str(epoch)+".ckpt")
            
            validaccrecord.append(valid_acc/ n_batch)
    
        trainingprocess_record = []
        trainingprocess_record.append(iterrecord)
        trainingprocess_record.append(trainaccrecord)
        trainingprocess_record.append(validaccrecord)
        np.save('./'+netname+'_trainrecord.npy',trainingprocess_record)
            
    coord.request_stop() #stop thread
    coord.join(threads)
    sess.close()