# -*- coding: utf-8 -*-
"""
Created on Mon May  7 15:33:25 2018

@author: Xie Lipeng
"""

import numpy as np
from utils.write_read_tfrecord import *
import tensorflow as tf
import tensorlayer as tl 
from PIL import Image
import matplotlib.pyplot as plt
import glob
import scipy.misc
import os
import nibabel as nib
from nets.construct_model import *


def Dice_Jaccard_ND(G,S):
    GS_Inter = G & S
    GS_Inter = np.sum(GS_Inter)
    GS_Union = G | S
    GS_Union = np.sum(GS_Union)

    G = np.sum(G)
    S = np.sum(S)
    Dice = 2*GS_Inter/(G+S+1e-6)
    Jaccard  = GS_Inter/(GS_Union+1e-6)               
    return Dice, Jaccard
    
def Pixel_evalution_ND(G,S):
    T1 = np.sum(G&S)  
    T0 = np.sum(np.logical_not(G)&np.logical_not(S)) 
    P = T1/(np.sum(G)+1e-6)
    Q = T0/(np.sum(np.logical_not(G))+1e-6)
    PPV = T1/(np.sum(S)+1e-6)
    NPV = T0/(np.sum(np.logical_not(S))+1e-6)
    return P,Q,PPV,NPV
    
def MaxMin_normalization(I):
    Maxval = np.max(I)
    Minval = np.min(I)
    II=np.int16((I-Minval)/(Maxval-Minval)*255)
    return II


#=========================step1: Set parameters===============================
netname = 'Unet_PW' #'Fcn8s','Hed','Unet','Proposed_Without_PW','Proposed'
model_name = "model_tfrecord.ckpt"
locationnum = 5

#==============================================================================
model_path = './checkpoints/'+netname+'/'
save_path = './outputs/'+netname+'/'
datapath = './data/'  #the path to store patches and lmdb
datapath_images = './data/testing-set/'
if not os.path.exists(save_path):
    os.mkdir(save_path)
#patchpathlist = glob.glob(datapath+'patches_'+'*')
model_file_name = model_path + model_name

mean_file_name = './data/train_1_1.tfrecords_mean.npy'
option_resume = True # load model, resume from previous checkpoint?

batch_size = 1
data_shape = [256,256,1]
mean_file_name = './data/train_1_1.tfrecords_mean.npy'
is_train = False
reuse= False
#=========================step3: Creat network===============================
# Define the batchsize at the begin, you can give the batchsize in x and y_

x = tf.placeholder(tf.float32, shape=[batch_size,data_shape[0],data_shape[1],data_shape[2]])   # [batch_size, height, width, channels]
y_ = tf.placeholder(tf.float32, shape=[batch_size,data_shape[0],data_shape[1], 2])

if netname=='Proposed' or netname=='Proposed_Without_PW'or netname=='Unet_PW':
    exec('network_predict,op_class,_ = model_'+netname+'(x, y_, batch_size, data_shape, reuse=reuse, mean_file_name=mean_file_name,is_train = is_train)')
else:
    exec('[network_predict,op_class,_] = model_'+netname+'(x,y_,batch_size,reuse=reuse,mean_file_name=mean_file_name, is_train = is_train)')
   

sess = tf.Session()
init = tf.initialize_all_variables()  
sess.run(init)
print("Load existing model " + "!"*10)
saver = tf.train.Saver()
saver.restore(sess, model_file_name)

#network.print_params(False)
#network.print_layers()

#=========================step4: Load image===============================

NiiList = glob.glob("%s*_seg.nii.gz" %(datapath_images))
Num_Nii = len(NiiList)
Num_iter = 0
NiiNameList = []
Evalution_Record = np.zeros([6,locationnum,Num_Nii])

for imgmaskname in sorted(NiiList):
    
    if Num_iter%5==0 | Num_iter==Num_Nii:
        print('Processing progress: %%f' %(Num_iter*100/Num_Nii))
    
    imgpathname = imgmaskname[:-9]
    imgname = imgmaskname.split('\\')[1]
    imgname = imgname.split('_seg')[0]
    NiiNameList.append(imgname) 
    image = nib.load(datapath_images+imgname+'.nii.gz')
    img_shape = image.shape
    imgdata = image.get_data()

    
    PredictClass = np.zeros(img_shape)
    if img_shape[0]!=data_shape[0] or img_shape[1]!=data_shape[1]:
        for ii in range(img_shape[3]):
            for jj in range(img_shape[2]):
                imagesub = imgdata[:,:,jj,ii]

                img_ori = np.array(imagesub)
                img_ori = MaxMin_normalization(img_ori)
                img = Image.fromarray(np.uint8(img_ori))
                img = img.resize((data_shape[0],data_shape[1]))
                img = np.array(img)
                
                img = img[np.newaxis,:,:,np.newaxis]
                feed_dict = {x: img}
                prediction_class_out = sess.run(op_class, feed_dict=feed_dict) 
                prediction_class = prediction_class_out[0,:,:,0]

                prediction_class= Image.fromarray(np.uint8(prediction_class))
                prediction_class= prediction_class.resize((img_shape[1],img_shape[0]))
                prediction_class= np.array(prediction_class)
     
                
                PredictClass[:,:,jj,ii] = prediction_class
                
    else:
        for ii in range(img_shape[3]):
            for jj in range(img_shape[2]):
                imagesub = imgdata[:,:,jj,ii]
                img_ori = np.array(imagesub)
                img  = MaxMin_normalization(img_ori)
        
                img = img[np.newaxis,:,:,np.newaxis]
                feed_dict = {x: img}
                prediction_class_out = sess.run(op_class, feed_dict=feed_dict) 
                prediction_class = prediction_class_out[0,:,:,0]                      
                PredictClass[:,:,jj,ii] = prediction_class
          
    Mask = nib.load(datapath_images+imgname+'_seg.nii.gz')
    Mask = Mask.get_data()
    Seg = PredictClass>0
    index = np.int32(np.linspace(0,img_shape[2],locationnum+1))
    for k in range(locationnum):
        Seg_temp = Seg[:,:,index[k]:index[k+1],:]
        Mask_temp = Mask[:,:,index[k]:index[k+1],:]
        Seg_shape = np.shape(Seg_temp)
        Dice_acc_list = []
        Jaccard_list = []
        P_list = []
        Q_list = []
        PPV_list = []
        NPV_list = []

        for ii in range(Seg_shape[2]):
            for jj in range(Seg_shape[3]):
                D,J = Dice_Jaccard_ND(Mask_temp[:,:,ii,jj],Seg_temp[:,:,ii,jj])
                Dice_acc_list.append(D)
                Jaccard_list.append(J)
                
                P,Q,PPV,NPV = Pixel_evalution_ND(Mask_temp[:,:,ii,jj],Seg_temp[:,:,ii,jj])
                P_list.append(P)
                Q_list.append(Q)
                PPV_list.append(PPV)
                NPV_list.append(NPV)
        A=np.array([Dice_acc_list,Jaccard_list,P_list,Q_list,PPV_list,NPV_list])
        Evalution_Record[:,k,Num_iter] = np.mean(A,1)
    Num_iter = Num_iter + 1




np.save('./Evaluation_VL_'+netname,Evalution_Record)

#=========================step4: Train network===============================
sess.close()