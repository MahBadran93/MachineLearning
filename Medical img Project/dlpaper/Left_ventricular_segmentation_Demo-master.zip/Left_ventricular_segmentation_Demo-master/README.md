# Left_ventricular_segmentation_Demo
![LV segmentation_Example](https://github.com/appiek/Left_ventricular_segmentation_Demo/blob/master/LV_Segmentation.gif?raw=true)
![LV segmentation_Example2](https://github.com/appiek/Left_ventricular_segmentation_Demo/blob/master/LV_Segmentation_2.gif?raw=true)  
Left Ventricle Segmentation in Short-axis MRI using Dynamic Pixel-wise Weighting-based Fully Convolutional Neural Networks  
![LV segmentation result at apex](https://github.com/appiek/Left_ventricular_segmentation_Demo/blob/master/Example_apex.png?raw=true)  ![LV segmentation result at mid](https://github.com/appiek/Left_ventricular_segmentation_Demo/blob/master/Example_mid.png?raw=true)  ![LV segmentation result at base](https://github.com/appiek/Left_ventricular_segmentation_Demo/blob/master/Example_basal.png?raw=true)  
* Left image: the LV segmentation result at apex position (red contour: segmentation result by our method, green contour: ground tuth)
* Middle image: the LV segmentation result at mid position
* Right image:  the LV segmentation result at base position

## Overview
We develop a novel Dynamic Pixel-wise Weighting-based Fully Convolutional Neural Networks for Left Ventricle segmentation, which can dynamically adjust the importance of pixels during training stage and improve the final segmentation perforance. We implemented our method based on the open-source machine learning framework TensorFlow and reinforcement learning library TensorLayer. This repository contains all code used in our experiments, incuding the data preparation, model construction, model training and result evaluation. For comparison with our method, we also utilized TensorFlow and TensorLayer to reimplement four known semantic segmentation convolutional neural networks: FCN8s, U-Net, HED.

## Dependencies  
* Matlab
* Python 3.5
* TensorFlow 1.x
* TensorLayer 1.5.4
* Scikit-image 13.0
* nibabel
* Numpy
* Scipy

## Dataset
We conducted the experiments on public Caridac MRI dataset, which is provided by the Cardiac Atlas Project [Link](http://www.cardiacatlas.org/). The dataset contains 83 ”Nii.gz”-formatted files for training and another 73 files for testing. However, only the training files have corresponding expert-guided manual segmentation results of myocardium. So we divide the training ”Nii.gz”-formatted files into two parts: training data with 50 files and testing data with 33 files.

## Composition of code
1. the main steps for data preparation, model training and result evaluation:
    * step_1: randomly extracting the image patches from ”Nii.gz”-formatted files 
    * step_2: randomly divide the image patches as training and validation data
    * step_3: transforming the image patches into tfrecord file
    * step_4: training multiple networks with same hyper-parameters
    * step_5: using the networks to segment the testing images for obtaining the region of LV 
    * step_5_contour: using the networks to segment the testing images for obtaining the contour of LV
    * step_6: evaluating the segmentation results at object-level
    * step_7: evaluating the segmentation results at various positions
2. ./tools: image patches generation
3. ./nets: model construction
4. ./utils: producing tfrecord file 
5. ./loaddata: matlab code for loading the ”Nii.gz”-formatted files

## Quick Start
* Testing: if you just want to validate the segmentation performance of pre-trained models, follow these steps:
   1. Download our code on your computer, assume the path is "./";
   2. Download the testing dataset file [Link](https://drive.google.com/open?id=1PlNbIFDhm2VRyE9wTSfPb2X5qTh6KJK6) and unzip this file into the path './dataset/testing-set'
   3. Download the pre-trained parameters of model: FCN8s [Link](https://drive.google.com/open?id=1dw490YxN3W39GLJ2l3xgFVY39TDr5HyN), HED [Link](https://drive.google.com/open?id=1QaevlJwMGIXa5PTzkAW7W5IV8AoBw0hS), Unet [Link](https://drive.google.com/open?id=1KpT0K-Fh8XOv1Nw-2B9_63tkX6mhKbNq), Proposed_Without_PW [Link](https://drive.google.com/open?id=1BXwMmoj2nCnUy22Q0x2kDy4kI7EGG9xg), Proposed [Link](https://drive.google.com/open?id=1v7gdml8hzeL6qrDyh9dwvMbfnY-Bf3MZ), and unzip this file into the path './checkpoints/'
   4. run the code from "step_5" to "step_7" for segmenting the testing images and evaluating the performance of method

## Contact information  
* E-mail: xlpflyinsky@foxmail.com

## Please cite our paper as below:
@article{WANG2019,  
title = "Dynamic Pixel-wise Weighting-based Fully Convolutional Neural Networks for Left Ventricle Segmentation in Short-axis MRI",  
journal = "Magnetic Resonance Imaging",  
year = "2019",  
issn = "0730-725X",  
doi = "https://doi.org/10.1016/j.mri.2019.08.021",  
url = "http://www.sciencedirect.com/science/article/pii/S0730725X18302819",  
author = "Zhongrong Wang and Lipeng Xie and Jin Qi",  
}
