# -*- coding: utf-8 -*-
"""
Created on Mon Jul 24 15:34:41 2017

@author: XLP
"""

from utils.write_read_tfrecord import *
import os.path as osp
import tensorflow as tf 
from PIL import Image
import matplotlib.pyplot as plt

 
#=========================step1: Set parameters===============================
datapath = './data/'  #the path to store patches and lmdb
save_path = './data/'
npatches = 1
nfolds = 1
#patchpathlist = glob.glob(datapath+'patches_'+'*')

data_shape = [224,224];
#=========================step2: Creat tfrecord===================================
for i in range(1,npatches+1,1):
    imgpath = datapath + 'training-set_'+str(i)
    for j in range(1,nfolds+1,1):
        train_datalist = osp.join(imgpath,'patches_train_'+str(j)+'.txt')
        test_datalist = osp.join(imgpath,'patches_valid_'+str(j)+'.txt')
        train_tfrecord = osp.join(save_path,'train_'+str(i)+'_'+str(j)+'.tfrecords')
        test_tfrecord = osp.join(save_path,'valid_'+str(i)+'_'+str(j)+'.tfrecords')   
        write_images_tfrecord(train_datalist,imgpath,train_tfrecord,data_shape,True)
        write_images_tfrecord(test_datalist,imgpath,test_tfrecord,data_shape)

img, label = read_and_decode(test_tfrecord,data_shape)      
batch_size = 10
#使用shuffle_batch可以随机打乱输入
img_batch, label_batch = tf.train.shuffle_batch([img, label],
                                                batch_size=batch_size, capacity=1000,
                                                min_after_dequeue=500)

y_back = tf.slice(label_batch,[0,0,0,0],[batch_size,data_shape[0],data_shape[1],1])
y_fore = tf.slice(label_batch,[0,0,0,1],[batch_size,data_shape[0],data_shape[1],1])
#=========================step3: Test tfrecord===================================
init = tf.global_variables_initializer()
coord = tf.train.Coordinator() #stop thread
with tf.Session() as sess:
    sess.run(init)
    threads = tf.train.start_queue_runners(sess=sess,coord=coord)
    for i in range(20):
        val, l, y_b, y_f= sess.run([img_batch, label_batch, y_back, y_fore])
        #我们也可以根据需要对val， l进行处理
        #l = to_categorical(l, 12) 
        print(val.shape)
    coord.request_stop() #stop thread

