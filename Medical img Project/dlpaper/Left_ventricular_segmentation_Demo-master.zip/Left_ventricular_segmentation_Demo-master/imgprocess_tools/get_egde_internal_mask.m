function [internal_mask,edge_mak] = get_egde_internal_mask(Img_mak,dilate_size)
%==========================================================================
% This code is used to eliminate the edge of mask.
%-------------------------------------------------------------------------
% Author:Lipeng Xie
% Date:2016-8-19
%==========================================================================
io_orig=Img_mak;
internal_mask=bwmorph(io,'erode',dilate_size); %dilate the image
edge_mak=io & ~io_orig; %sub
