function patch_names = img_patch_pixel_label_extract_size_rots(im_ori,im_pl,im_mask,Contour_mask,PatchDataInfo_struct,imgname,hwsize,max_num,prefix,ratio_imgsize,orient_transf)
%==========================================
% Cuting the image into patches
% im_ori: original image
% im_pl: the pixel label of image
% im_mask: the region of examples
% patches_outdir,innerlabels_outdir: the output dir path of patches and corresponding pixel label 
% imgname: the name of image
% hwsize: thehalf of window size
% max_num: the maxmium number of examples
% class: 
% prefix:
% ratio_imgsize:
% orient_transf:
%==========================================

patches_outdir = PatchDataInfo_struct.folderpath;

numsize = length(ratio_imgsize);
numrot = length(orient_transf);

threshold_pixel = 0.2*ratio_imgsize;

patch_names = cell(numsize,1);
for itersize=1:numsize
    if ratio_imgsize(itersize)~=1
       Img_ori = imresize(im_ori,ratio_imgsize(itersize));
       Img_mask = imresize(im_mask,ratio_imgsize(itersize));
       Img_pl = imresize(im_pl,ratio_imgsize(itersize));
%        Img_contour = imresize(Contour_mask,ratio_imgsize(itersize));
    else
       Img_ori = im_ori;
       Img_mask = im_mask;
       Img_pl = im_pl;
%        Img_contour = Contour_mask;
    end
    
    image_size=size(Img_ori); %get image size
    [r,c]=find(Img_mask);
    toremove= r+2*hwsize > image_size(1) | c+2*hwsize > image_size(2) | r-2*hwsize < 1 | c-2*hwsize < 1  ; %remove all pixels near the boundary as they won't result in full patches.
    
    fprintf('Image:%s Size: %.2fx removed: %d\n',imgname,ratio_imgsize(itersize),sum(toremove));
    r(toremove)=[]; %remove them from the list
    c(toremove)=[]; %remove them from the list
    idx=randperm(length(r)); %generate a permuted list
    r=r(idx);   %permute the list
    c=c(idx);
    ni=min(length(r),round(max_num)); %figure out how many we're going to take, 
    
    patch_subnames = cell(ni,1);
    pixelnum = 4*hwsize^2;
    parfor ri=1:ni %we do this in a parallel for loop because the cropping + rotation are cpu bound operatins
        patch=Img_ori(r(ri)-2*hwsize:r(ri)+2*hwsize-1,c(ri)-2*hwsize:c(ri)+2*hwsize-1,:);  %extract the patch
        patch_mask=Img_pl(r(ri)-2*hwsize:r(ri)+2*hwsize-1,c(ri)-2*hwsize:c(ri)+2*hwsize-1,:);  %extract the patch
%         patch_mask_contour=Img_contour(r(ri)-2*hwsize:r(ri)+2*hwsize-1,c(ri)-2*hwsize:c(ri)+2*hwsize-1,:);  %extract the patch
        subnaems = {};
        for roti=1:length(orient_transf) %handle each rotation serially
            degr=orient_transf(roti);    
            rpatch=imrotate(patch,degr,'crop'); %rotate the patch appropriately
            rpatch_mask=imrotate(patch_mask,degr,'crop');
%             rpatch_mask_contour = imrotate(patch_mask_contour,degr,'crop');
            %=================Ensure region label and save inner and comtour label====================================
            [nrow,ncol,ndim]=size(rpatch_mask);
            rpatch_mask=rpatch_mask(nrow/2-hwsize:nrow/2+hwsize-1,ncol/2-hwsize:ncol/2+hwsize-1,:); %pull the subpatch of the correct size (see above)
%             rpatch_mask_contour = rpatch_mask_contour(nrow/2-hwsize:nrow/2+hwsize-1,ncol/2-hwsize:ncol/2+hwsize-1,:);
            if sum(sum(rpatch_mask))/pixelnum >= threshold_pixel(itersize)
                classname = 1;
            else
                classname = 0;
            end
            pname=sprintf('%s_%s_%d_%.2fx_%d_%d_il.png',imgname,prefix,ri,ratio_imgsize(itersize),degr,classname ); %generate a filename for it
            imwrite(rpatch_mask,sprintf('%s/%s',patches_outdir,pname)); %save the image patch to the output directoy
%             pname=sprintf('%s_%s_%d_%.2fx_%d_%d_cl.png',imgname,prefix,ri,ratio_imgsize(itersize),degr,classname ); %generate a filename for it
%             imwrite(rpatch_mask_contour,sprintf('%s/%s',patches_outdir,pname)); %save the image patch to the output directoy
            %================save patch data=====================================
            [nrow,ncol,ndim]=size(rpatch);
            rpatch=rpatch(nrow/2-hwsize:nrow/2+hwsize-1,ncol/2-hwsize:ncol/2+hwsize-1,:); %pull the subpatch of the correct size (see above)
            pname=sprintf('%s_%s_%d_%.2fx_%d_%d.png',imgname,prefix,ri,ratio_imgsize(itersize),degr,classname); %generate a filename for it
            subnaems{roti}=pname; %add the filename to the list
            imwrite(rpatch,sprintf('%s/%s',patches_outdir,pname)); %save the image patch to the output directoy
                      
        end
        patch_subnames{ri} = subnaems;
    end
    patch_names{itersize} = patch_subnames;
end




