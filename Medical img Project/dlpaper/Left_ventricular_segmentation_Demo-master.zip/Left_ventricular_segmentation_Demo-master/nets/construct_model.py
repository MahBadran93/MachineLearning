# -*- coding: utf-8 -*-
"""
Created on Sun Aug  6 21:36:50 2017

@author: XLP
"""
import tensorflow as tf
import tensorlayer as tl
import numpy as np
from tensorlayer.layers import *
Layer = tl.layers.Layer

def image_preprocess(img,meanval):
    meanval = tf.constant(meanval,tf.float32)
    img = tf.cast(img, tf.float32) 
    img = tf.subtract(img, meanval)* (1./255)
    return img

class Mergelayer(Layer):
    def __init__(
        self,
        layer = [],
        name ='merge_layer',
    ):
        Layer.__init__(self, prev_layer=None, name=name)
        
        self.all_layers = list(layer[0].all_layers)
        self.all_params = list(layer[0].all_params)
        self.all_drop = dict(layer[0].all_drop)

        for i in range(1, len(layer)):
            self.all_layers.extend(list(layer[i].all_layers))
            self.all_params.extend(list(layer[i].all_params))
            self.all_drop.update(dict(layer[i].all_drop))

        self.all_layers = list_remove_repeat(self.all_layers)
        self.all_params = list_remove_repeat(self.all_params)     
    

	
def model_Proposed(x, y_, batch_size, data_shape, reuse, mean_file_name=None,is_train = True):
    if mean_file_name!=None:
        meanval = np.load(mean_file_name)
        x = image_preprocess(x,meanval)
    drop_rate = 0.5 
    sida = 0.000001
    gamma_init=tf.random_normal_initializer(2., 0.01)
    with tf.variable_scope("VGG16_PixelRew_BN", reuse=reuse):
        tl.layers.set_name_reuse(reuse)
        network_input = tl.layers.InputLayer(x, name='input')
        """ conv1 """
        network1 = tl.layers.Conv2dLayer(network_input, shape = [3, 3, data_shape[2], 64],
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv1_1')
        network1 = tl.layers.Conv2dLayer(network1, shape = [3, 3, 64, 64],    # 64 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv1_2')
        network1 = tl.layers.BatchNormLayer(network1, act = tf.nn.relu, is_train=is_train, gamma_init=gamma_init, name='bn1')
        network1 = tl.layers.PoolLayer(network1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],padding='SAME', 
                    pool = tf.nn.max_pool, name ='pool1') #outputsize: [H/2,W/2]
        """ conv2 """
        network1 = tl.layers.DropoutLayer(network1,keep=drop_rate,is_train=is_train,name='drop_net1')
        network2 = tl.layers.Conv2dLayer(network1, shape = [3, 3, 64, 128],  # 128 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv2_1')
        network2 = tl.layers.Conv2dLayer(network2, shape = [3, 3, 128, 128],  # 128 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv2_2')
        network2 = tl.layers.BatchNormLayer(network2, act = tf.nn.relu, is_train=is_train, gamma_init=gamma_init, name='bn2')
        network2 = tl.layers.PoolLayer(network2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],
                    padding='SAME', pool = tf.nn.max_pool, name ='pool2') #outputsize: [H/4,W/4]
        """ conv3 """
        network2 = tl.layers.DropoutLayer(network2,keep=drop_rate,is_train=is_train,name='drop_net2')
        network3 = tl.layers.Conv2dLayer(network2, shape = [3, 3, 128, 256],  # 256 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv3_1')
        network3 = tl.layers.Conv2dLayer(network3, shape = [3, 3, 256, 256],  # 256 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv3_2')
        network3 = tl.layers.Conv2dLayer(network3, shape = [3, 3, 256, 256],  # 256 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv3_3')
        network3 = tl.layers.BatchNormLayer(network3, act = tf.nn.relu, is_train=is_train, gamma_init=gamma_init, name='bn3')
        network3 = tl.layers.PoolLayer(network3, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],
                    padding='SAME', pool = tf.nn.max_pool, name ='pool3') #outputsize: [H/8,W/8]
        """ conv4 """
        network3 = tl.layers.DropoutLayer(network3,keep=drop_rate,is_train=is_train,name='drop_net3')
        network4 = tl.layers.Conv2dLayer(network3, shape = [3, 3, 256, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv4_1')
        network4 = tl.layers.Conv2dLayer(network4, shape = [3, 3, 512, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv4_2')
        network4 = tl.layers.Conv2dLayer(network4, shape = [3, 3, 512, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv4_3')
        network4 = tl.layers.BatchNormLayer(network4, act = tf.nn.relu, is_train=is_train, gamma_init=gamma_init, name='bn4')
        network4 = tl.layers.PoolLayer(network4, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],
                    padding='SAME', pool = tf.nn.max_pool, name ='pool4') #outputsize: [H/16,W/16]
        """ conv5 """
        network4 = tl.layers.DropoutLayer(network4,keep=drop_rate,is_train=is_train,name='drop_net4')
        network5 = tl.layers.Conv2dLayer(network4, shape = [3, 3, 512, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv5_1')
        network5 = tl.layers.Conv2dLayer(network5, shape = [3, 3, 512, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv5_2')
        network5 = tl.layers.Conv2dLayer(network5, shape = [3, 3, 512, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv5_3')
        network5 = tl.layers.BatchNormLayer(network5, act = tf.nn.relu, is_train=is_train, gamma_init=gamma_init, name='bn5')
        network5 = tl.layers.PoolLayer(network5, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],
                    padding='SAME', pool = tf.nn.max_pool, name ='pool5') #outputsize: [H/32,W/32]
        network5 = tl.layers.DropoutLayer(network5,keep=drop_rate,is_train=is_train,name='drop_net5')
        '#########################Upsample and merge##########################'
        '''top-down 5'''
        network5_conv = tl.layers.Conv2dLayer(network5, shape = [3, 3, 512, 64], act = tf.nn.relu,  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv5_conv')
        network5_up = tl.layers.UpSampling2dLayer(network5_conv,
                    size = [data_shape[0]//16,data_shape[1]//16],method =0,is_scale = False,name = 'upsample5' )   # output:[H/16,W/16,64]
        '''top-down 4'''
        network4_conv = tl.layers.Conv2dLayer(network4, shape = [3, 3, 512, 64], act = tf.nn.relu, # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv4_conv')
        network_cmb4_5 = tl.layers.ConcatLayer([network4_conv,network5_up],
                    concat_dim = 3, name = 'concat_4_5') # output:[H/16,W/16,128]
        network4_up = tl.layers.UpSampling2dLayer(network_cmb4_5, 
                    size = [data_shape[0]//8,data_shape[1]//8], method =0,is_scale = False,name = 'upsample4' )   # output:[H/8,W/8,128]
        '''top-down 3'''
        network3_conv = tl.layers.Conv2dLayer(network3, shape = [3, 3, 256, 64], act = tf.nn.relu, # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv3_conv') # output:[H/8,W/8,64]
        network_cmb3_4 = tl.layers.ConcatLayer([network3_conv,network4_up],
                    concat_dim = 3, name = 'concat_3_4')# output:[H/8,W/8,192]
        network3_up = tl.layers.UpSampling2dLayer(network_cmb3_4, 
                    size = [data_shape[0]//4,data_shape[1]//4], method =0,is_scale = False,name = 'upsample3' )   # output:[H/4,W/4,192]
        '''top-down 2'''
        network2_conv = tl.layers.Conv2dLayer(network2, shape = [3, 3, 128, 64],act = tf.nn.relu,  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv2_conv') # output:[H/4,W/4,64]
        network_cmb2_3 = tl.layers.ConcatLayer([network2_conv,network3_up],
                    concat_dim = 3, name = 'concat_2_3')# output:[H/4,W/4,256]
        network2_up = tl.layers.UpSampling2dLayer(network_cmb2_3, 
                    size = [data_shape[0]//2,data_shape[1]//2], method =0,is_scale = False,name = 'upsample2' )   # output:[H/2,W/2,256]

        '''top-down 1'''
        network1_conv = tl.layers.Conv2dLayer(network1, shape = [3, 3, 64, 64], act = tf.nn.relu, # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv1_conv') # output:[H/2,W/2,64]
        network_cmb1_2 = tl.layers.ConcatLayer([network1_conv,network2_up],
                    concat_dim = 3, name = 'concat1_2')# output:[H/2,W/2,320]
        network1_up = tl.layers.UpSampling2dLayer(network_cmb1_2, 
                    size = [data_shape[0],data_shape[1]], method =0,is_scale = False,name = 'upsample1' )   # output:[H,W,320]
        
                                                                           
        
        """## cost of classification3"""
        network1_up = tl.layers.DropoutLayer(network1_up,keep=drop_rate,is_train=is_train,name='up1')
        network_class3 = tl.layers.Conv2dLayer(network1_up,             
               shape = [3, 3, 320, 160], # 64 features for each 5x5 patch
               strides=[1, 1, 1, 1],
               padding='SAME',
               W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
               b_init = tf.constant_initializer(value=0.0),
               name ='score1_feaconv')  # output: (?, 14, 14, 64)
        network_class3 = tl.layers.DropoutLayer(network_class3,keep=drop_rate,is_train=is_train,name='drop3')
        network_class3 = tl.layers.Conv2dLayer(network_class3,             
               shape = [3, 3, 160, 2], # 64 features for each 5x5 patch
               strides=[1, 1, 1, 1],
               padding='SAME',
               W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
               b_init = tf.constant_initializer(value=0.0),
               name ='output1')  # output: (?, 14, 14, 64)
        if is_train:
            """## cost of classification2"""
            network2_up = tl.layers.DropoutLayer(network2_up,keep=drop_rate,is_train=is_train,name='up2')
            network_class2 = tl.layers.Conv2dLayer(network2_up,             
                   shape = [3, 3, 256, 128], # 64 features for each 5x5 patch
                   strides=[1, 1, 1, 1],
                   padding='SAME',
                   W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),
                   name ='score2_feaconv')  # output: (?, 14, 14, 64)
            network_class2 = tl.layers.DropoutLayer(network_class2,keep=drop_rate,is_train=is_train,name='drop2')
            network_class2 = tl.layers.Conv2dLayer(network_class2,             
                   shape = [3, 3, 128, 2], # 64 features for each 5x5 patch
                   strides=[1, 1, 1, 1],
                   padding='SAME',
                   W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),
                   name ='score2_cmb1')  # output: (?, 14, 14, 64)
            network_class2 =tl.layers.UpSampling2dLayer(network_class2,
                   size = [data_shape[0],data_shape[1]],
                   method =0,
                   is_scale = False,
                   name = 'output2' )
            
            """## cost of classification1"""
            network3_up = tl.layers.DropoutLayer(network3_up,keep=drop_rate,is_train=is_train,name='up3')
            network_class1 = tl.layers.Conv2dLayer(network3_up,             
                   shape = [3, 3, 192, 96], # 64 features for each 5x5 patch
                   strides=[1, 1, 1, 1],
                   padding='SAME',
                   W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),
                   name ='score3_feaconv')  # output: (?, 14, 14, 64)
            network_class1 = tl.layers.DropoutLayer(network_class1,keep=drop_rate,is_train=is_train,name='drop1')
            network_class1 = tl.layers.Conv2dLayer(network_class1,             
                   shape = [3, 3, 96, 2], # 64 features for each 5x5 patch
                   strides=[1, 1, 1, 1],
                   padding='SAME',
                   W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),
                   name ='score3_cmb2')  # output: (?, 14, 14, 64)
            network_class1 =tl.layers.UpSampling2dLayer(network_class1,
                   size = [data_shape[0],data_shape[1]],
                   method =0,
                   is_scale = False,
                   name = 'output3' )
            
            ## merge all classification
            network_final = Mergelayer([network_class1,network_class2,network_class3],
                   name = 'mergeall'               )
                    
            #================Groundtruth==========================
            y_ = tf.reshape(y_,[batch_size*data_shape[0]*data_shape[1],2])
            w1 = tf.ones([batch_size*data_shape[0]*data_shape[1]])
    
            #================cost1================================
            y1 = network_class1.outputs   
            y1 = tf.reshape(y1,[batch_size*data_shape[0]*data_shape[1],2])
            y1_prob = tf.nn.softmax(y1)
            y1_class = tf.argmax(y1_prob, 1)
            crect_pred1 = tf.equal(y1_class, tf.argmax(y_,1)) 
            crect_pred1 = tf.cast(crect_pred1, "float")
            y1_class = tf.reshape(y1_class,[batch_size,data_shape[0],data_shape[1],1])
            
            cost1 = -tf.reduce_mean(tf.reduce_sum(y_*tf.log(y1_prob+sida),1))
        
            #================cost2================================
            acc1 = tf.reduce_mean(crect_pred1)
            alpha1 = -1.5*tf.log(acc1)
            w2 = tf.multiply(w1,tf.exp((0.5-crect_pred1)*2*alpha1))
            w2 = w2*data_shape[0]*data_shape[1]*batch_size/tf.reduce_sum(w2)
    
            y2 = network_class2.outputs   
            y2 = tf.reshape(y2,[batch_size*data_shape[0]*data_shape[1],2])
            y2_prob = tf.nn.softmax(y2)
            y2_class = tf.argmax(y2_prob, 1)
            crect_pred2 = tf.equal(y2_class, tf.argmax(y_,1)) 
            crect_pred2 = tf.cast(crect_pred2, "float")
            y2_class = tf.reshape(y2_class,[batch_size,data_shape[0],data_shape[1],1])
            
            cost2 = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y2_prob+sida),1),w2))
            
            #================cost3================================
            acc2 = tf.reduce_mean(crect_pred2)
            alpha2 = -1.5*tf.log(acc2)
            w3 = tf.multiply(w2,tf.exp((0.5-crect_pred2)*2*alpha2))
            w3 = w3*data_shape[0]*data_shape[1]*batch_size/tf.reduce_sum(w3)
    
            y3 = network_class3.outputs   
            y3 = tf.reshape(y3,[batch_size*data_shape[0]*data_shape[1],2])
            y3_prob = tf.nn.softmax(y3)
            y3_class = tf.argmax(y3_prob, 1)
            y3_class = tf.reshape(y3_class,[batch_size,data_shape[0],data_shape[1],1])
 
            
            cost3 = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y3_prob+sida),1),w3))
            cost = cost1+cost2+cost3
            #================costall================================
            return network_final,cost,y3_class
        else:
            y3 = network_class3.outputs  
#            phi = tf.slice(y3,[0,0,0,1],[batch_size,data_shape[0],data_shape[1],1])
            y3 = tf.reshape(y3,[batch_size*data_shape[0]*data_shape[1],2])
            y3_prob = tf.nn.softmax(y3)
            y3_class = tf.argmax(y3_prob, 1)
            y_final_class = tf.reshape(y3_class,[batch_size, data_shape[0],data_shape[1],1])
            
            y_final_prob = tf.slice(y3_prob,[0,1],[batch_size*data_shape[0]*data_shape[1],1])
            y_final_prob = tf.reshape(y_final_prob,[batch_size, data_shape[0],data_shape[1],1])
            return network_class3,y_final_class, y_final_prob      

			
def model_Proposed_Without_PW(x, y_, batch_size, data_shape, reuse, mean_file_name=None,is_train = True):
    if mean_file_name!=None:
        meanval = np.load(mean_file_name)
        x = image_preprocess(x,meanval)
    drop_rate = 0.5
    sida = 0.000001
    gamma_init=tf.random_normal_initializer(2., 0.01)
    with tf.variable_scope("VGG16_Without_PW", reuse=reuse):
        tl.layers.set_name_reuse(reuse)
        network_input = tl.layers.InputLayer(x, name='input')
        """ conv1 """
        network1 = tl.layers.Conv2dLayer(network_input, shape = [3, 3, data_shape[2], 64],
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv1_1')
        network1 = tl.layers.Conv2dLayer(network1, shape = [3, 3, 64, 64],    # 64 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv1_2')
        network1 = tl.layers.BatchNormLayer(network1, act = tf.nn.relu, is_train=is_train, gamma_init=gamma_init, name='bn1')
        network1 = tl.layers.PoolLayer(network1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],padding='SAME', 
                    pool = tf.nn.max_pool, name ='pool1') #outputsize: [H/2,W/2]
        """ conv2 """
        network1 = tl.layers.DropoutLayer(network1,keep=drop_rate,is_train=is_train,name='drop_net1')
        network2 = tl.layers.Conv2dLayer(network1, shape = [3, 3, 64, 128],  # 128 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv2_1')
        network2 = tl.layers.Conv2dLayer(network2, shape = [3, 3, 128, 128],  # 128 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv2_2')
        network2 = tl.layers.BatchNormLayer(network2, act = tf.nn.relu, is_train=is_train, gamma_init=gamma_init, name='bn2')
        network2 = tl.layers.PoolLayer(network2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],
                    padding='SAME', pool = tf.nn.max_pool, name ='pool2') #outputsize: [H/4,W/4]
        """ conv3 """
        network2 = tl.layers.DropoutLayer(network2,keep=drop_rate,is_train=is_train,name='drop_net2')
        network3 = tl.layers.Conv2dLayer(network2, shape = [3, 3, 128, 256],  # 256 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv3_1')
        network3 = tl.layers.Conv2dLayer(network3, shape = [3, 3, 256, 256],  # 256 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv3_2')
        network3 = tl.layers.Conv2dLayer(network3, shape = [3, 3, 256, 256],  # 256 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv3_3')
        network3 = tl.layers.BatchNormLayer(network3, act = tf.nn.relu, is_train=is_train, gamma_init=gamma_init, name='bn3')
        network3 = tl.layers.PoolLayer(network3, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],
                    padding='SAME', pool = tf.nn.max_pool, name ='pool3') #outputsize: [H/8,W/8]
        """ conv4 """
        network3 = tl.layers.DropoutLayer(network3,keep=drop_rate,is_train=is_train,name='drop_net3')
        network4 = tl.layers.Conv2dLayer(network3, shape = [3, 3, 256, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv4_1')
        network4 = tl.layers.Conv2dLayer(network4, shape = [3, 3, 512, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv4_2')
        network4 = tl.layers.Conv2dLayer(network4, shape = [3, 3, 512, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv4_3')
        network4 = tl.layers.BatchNormLayer(network4, act = tf.nn.relu, is_train=is_train, gamma_init=gamma_init, name='bn4')
        network4 = tl.layers.PoolLayer(network4, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],
                    padding='SAME', pool = tf.nn.max_pool, name ='pool4') #outputsize: [H/16,W/16]
        """ conv5 """
        network4 = tl.layers.DropoutLayer(network4,keep=drop_rate,is_train=is_train,name='drop_net4')
        network5 = tl.layers.Conv2dLayer(network4, shape = [3, 3, 512, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv5_1')
        network5 = tl.layers.Conv2dLayer(network5, shape = [3, 3, 512, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv5_2')
        network5 = tl.layers.Conv2dLayer(network5, shape = [3, 3, 512, 512],  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv5_3')
        network5 = tl.layers.BatchNormLayer(network5, act = tf.nn.relu, is_train=is_train, gamma_init=gamma_init, name='bn5')
        network5 = tl.layers.PoolLayer(network5, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1],
                    padding='SAME', pool = tf.nn.max_pool, name ='pool5') #outputsize: [H/32,W/32]
        network5 = tl.layers.DropoutLayer(network5,keep=drop_rate,is_train=is_train,name='drop_net5')
        '#########################Upsample and merge##########################'
        '''top-down 5'''
        network5_conv = tl.layers.Conv2dLayer(network5, shape = [3, 3, 512, 64], act = tf.nn.relu,  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv5_conv')
        network5_up = tl.layers.UpSampling2dLayer(network5_conv,
                    size = [data_shape[0]//16,data_shape[1]//16],method =0,is_scale = False,name = 'upsample5' )   # output:[H/16,W/16,64]
        '''top-down 4'''
        network4_conv = tl.layers.Conv2dLayer(network4, shape = [3, 3, 512, 64], act = tf.nn.relu, # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv4_conv')
        network_cmb4_5 = tl.layers.ConcatLayer([network4_conv,network5_up],
                    concat_dim = 3, name = 'concat_4_5') # output:[H/16,W/16,128]
        network4_up = tl.layers.UpSampling2dLayer(network_cmb4_5, 
                    size = [data_shape[0]//8,data_shape[1]//8], method =0,is_scale = False,name = 'upsample4' )   # output:[H/8,W/8,128]
        '''top-down 3'''
        network3_conv = tl.layers.Conv2dLayer(network3, shape = [3, 3, 256, 64], act = tf.nn.relu, # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv3_conv') # output:[H/8,W/8,64]
        network_cmb3_4 = tl.layers.ConcatLayer([network3_conv,network4_up],
                    concat_dim = 3, name = 'concat_3_4')# output:[H/8,W/8,192]
        network3_up = tl.layers.UpSampling2dLayer(network_cmb3_4, 
                    size = [data_shape[0]//4,data_shape[1]//4], method =0,is_scale = False,name = 'upsample3' )   # output:[H/4,W/4,192]
        '''top-down 2'''
        network2_conv = tl.layers.Conv2dLayer(network2, shape = [3, 3, 128, 64],act = tf.nn.relu,  # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv2_conv') # output:[H/4,W/4,64]
        network_cmb2_3 = tl.layers.ConcatLayer([network2_conv,network3_up],
                    concat_dim = 3, name = 'concat_2_3')# output:[H/4,W/4,256]
        network2_up = tl.layers.UpSampling2dLayer(network_cmb2_3, 
                    size = [data_shape[0]//2,data_shape[1]//2], method =0,is_scale = False,name = 'upsample2' )   # output:[H/2,W/2,256]

        '''top-down 1'''
        network1_conv = tl.layers.Conv2dLayer(network1, shape = [3, 3, 64, 64], act = tf.nn.relu, # 512 features for each 3x3 patch
                    strides = [1, 1, 1, 1], padding='SAME', name ='conv1_conv') # output:[H/2,W/2,64]
        network_cmb1_2 = tl.layers.ConcatLayer([network1_conv,network2_up],
                    concat_dim = 3, name = 'concat1_2')# output:[H/2,W/2,320]
        network1_up = tl.layers.UpSampling2dLayer(network_cmb1_2, 
                    size = [data_shape[0],data_shape[1]], method =0,is_scale = False,name = 'upsample1' )   # output:[H,W,320]
        
                                                                           
        
        """## cost of classification3"""
        network1_up = tl.layers.DropoutLayer(network1_up,keep=drop_rate,is_train=is_train,name='up1')
        network_class3 = tl.layers.Conv2dLayer(network1_up,             
               shape = [3, 3, 320, 160], # 64 features for each 5x5 patch
               strides=[1, 1, 1, 1],
               padding='SAME',
               W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
               b_init = tf.constant_initializer(value=0.0),
               name ='score1_feaconv')  # output: (?, 14, 14, 64)
        network_class3 = tl.layers.DropoutLayer(network_class3,keep=drop_rate,is_train=is_train,name='drop3')
        network = tl.layers.Conv2dLayer(network_class3,             
               shape = [3, 3, 160, 2], # 64 features for each 5x5 patch
               strides=[1, 1, 1, 1],
               padding='SAME',
               W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
               b_init = tf.constant_initializer(value=0.0),
               name ='output1')  # output: (?, 14, 14, 64)
        #================Groundtruth==========================
        if is_train:        
            y_back = tf.slice(y_,[0,0,0,0],[batch_size,data_shape[0],data_shape[1],1])
            y_fore = tf.slice(y_,[0,0,0,1],[batch_size,data_shape[0],data_shape[1],1])
            w = y_back+y_fore*30
            y_ = tf.reshape(y_,[batch_size*data_shape[0]*data_shape[1],2])
            w = tf.reshape(w,[batch_size*data_shape[0]*data_shape[1]])
            
            
            y = network.outputs   
            y = tf.reshape(y,[batch_size*data_shape[0]*data_shape[1],2])
            y_prob = tf.nn.softmax(y)
            y_class = tf.argmax(y_prob, 1)
            y_class = tf.reshape(y_class,[batch_size,data_shape[0],data_shape[1],1])
            
            cost = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y_prob+sida),1),w))
            return network,cost,y_class
            
        else:
            y = network.outputs   
            y = tf.reshape(y,[batch_size*data_shape[0]*data_shape[1],2])
            y_prob = tf.nn.softmax(y)
            y_class = tf.argmax(y_prob, 1)
            y_class = tf.reshape(y_class,[batch_size,data_shape[0],data_shape[1],1])
        
            y_prob = tf.slice(y_prob,[0,1],[batch_size*data_shape[0]*data_shape[1],1])
            y_prob = tf.reshape(y_prob,[batch_size,data_shape[0],data_shape[1],1])
            return network, y_class, y_prob  			
			
def model_Fcn8s(x,y_,batch_size, reuse, mean_file_name=None,is_train = True):
    if mean_file_name!=None:
        meanval = np.load(mean_file_name)
        x = image_preprocess(x,meanval)
    _, nx, ny, nz = x.get_shape().as_list()
    sida = 0.000001
    with tf.variable_scope("fcn8s", reuse=reuse):
        tl.layers.set_name_reuse(reuse)
        inputs = InputLayer(x, name='inputs')
        conv1 = Conv2d(inputs, 64, (3, 3), act=tf.nn.relu, name='conv1_1')
        conv1 = Conv2d(conv1, 64, (3, 3), act=tf.nn.relu, name='conv1_2')
        pool1 = MaxPool2d(conv1, (2, 2), name='pool1')
        
        conv2 = Conv2d(pool1, 128, (3, 3), act=tf.nn.relu, name='conv2_1')
        conv2 = Conv2d(conv2, 128, (3, 3), act=tf.nn.relu, name='conv2_2')
        pool2 = MaxPool2d(conv2, (2, 2), name='pool2')
        
        conv3 = Conv2d(pool2, 256, (3, 3), act=tf.nn.relu, name='conv3_1')
        conv3 = Conv2d(conv3, 256, (3, 3), act=tf.nn.relu, name='conv3_2')
        conv3 = Conv2d(conv3, 256, (3, 3), act=tf.nn.relu, name='conv3_3')
        pool3 = MaxPool2d(conv3, (2, 2), name='pool3')
        
        conv4 = Conv2d(pool3, 512, (3, 3), act=tf.nn.relu, name='conv4_1')
        conv4 = Conv2d(conv4, 512, (3, 3), act=tf.nn.relu, name='conv4_2')
        conv4 = Conv2d(conv4, 512, (3, 3), act=tf.nn.relu, name='conv4_3')   
        pool4 = MaxPool2d(conv4, (2, 2), name='pool4')
        
        conv5 = Conv2d(pool4, 512, (3, 3), act=tf.nn.relu, name='conv5_1')
        conv5 = Conv2d(conv5, 512, (3, 3), act=tf.nn.relu, name='conv5_2')
        conv5 = Conv2d(conv5, 512, (3, 3), act=tf.nn.relu, name='conv5_3')
        pool5 = MaxPool2d(conv5, (2, 2), name='pool5')
        
        fc6 = Conv2d(pool5, 4096, (7, 7), act=tf.nn.relu, name='fc6')
        #================drop=======================================
        drop6 = DropoutLayer(fc6, keep=0.8, is_train=is_train, name='drop6')
        
        fc7 = Conv2d(drop6, 4096, (1, 1), act=tf.nn.relu, name='fc7')
        #================drop=======================================
        drop7 = DropoutLayer(fc7, keep=0.8, is_train=is_train, name='drop7')
        
        score_fr = Conv2d(drop7 , 2, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='score_fr')
        upscore2 = DeConv2d(score_fr, 2, (4, 4), (nx/16, ny/16), (2, 2), name='upscore2')
        score_pool4 = Conv2d(pool4, 2, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='score_pool4') 
        fuse_pool4 = ElementwiseLayer([upscore2, score_pool4], combine_fn = tf.add, name='fuse_pool4')
        
        upscore_pool4 = DeConv2d(fuse_pool4, 2, (4, 4), (nx/8, ny/8), (2, 2), name='upscore_pool4')
        score_pool3 = Conv2d(pool3, 2, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='score_pool3') 
        fuse_pool3 = ElementwiseLayer([upscore_pool4, score_pool3],  combine_fn = tf.add, name='fuse_pool3')
        
        network = DeConv2d(fuse_pool3, 2, (16, 16), (nx, ny), (8, 8), name='upscore8')
        
      
        #================Groundtruth==========================
        if is_train:        
            y_back = tf.slice(y_,[0,0,0,0],[batch_size,nx,ny,1])
            y_fore = tf.slice(y_,[0,0,0,1],[batch_size,nx,ny,1])
            w = y_back+y_fore*30
            y_ = tf.reshape(y_,[batch_size*nx*ny,2])
            w = tf.reshape(w,[batch_size*nx*ny])
            
            
            y = network.outputs   
            y = tf.reshape(y,[batch_size*nx*ny,2])
            y_prob = tf.nn.softmax(y)
            y_class = tf.argmax(y_prob, 1)
            y_class = tf.reshape(y_class,[batch_size,nx,ny,1])
            
            cost = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y_prob+sida),1),w))
            return network ,cost,y_class
            
        else:
            y = network.outputs   
            y = tf.reshape(y,[batch_size*nx*ny,2])
            y_prob = tf.nn.softmax(y)
            y_class = tf.argmax(y_prob, 1)
            y_class = tf.reshape(y_class,[batch_size,nx,ny,1])
        
            y_prob = tf.slice(y_prob,[0,1],[batch_size*nx*ny,1])
            y_prob = tf.reshape(y_prob,[batch_size,nx,ny,1])
            return network, y_class, y_prob
 
 
def model_Hed(x, y_, batch_size, reuse, mean_file_name=None, is_train = True):
    if mean_file_name!=None:
        meanval = np.load(mean_file_name)
        x = image_preprocess(x,meanval)
    _, nx, ny, nz = x.get_shape().as_list()
    sida = 0.000001
    with tf.variable_scope("hed", reuse=reuse):
        tl.layers.set_name_reuse(reuse)
        inputs =InputLayer(x, name='inputs')
        conv1 = Conv2d(inputs, 64, (3, 3), act=tf.nn.relu, name='conv1_1')
        conv1 = Conv2d(conv1, 64, (3, 3), act=tf.nn.relu, name='conv1_2')
        pool1 = MaxPool2d(conv1, (2, 2), name='pool1')
        
        conv2 = Conv2d(pool1, 128, (3, 3), act=tf.nn.relu, name='conv2_1')
        conv2 = Conv2d(conv2, 128, (3, 3), act=tf.nn.relu, name='conv2_2')
        pool2 = MaxPool2d(conv2, (2, 2), name='pool2')
        
        conv3 = Conv2d(pool2, 256, (3, 3), act=tf.nn.relu, name='conv3_1')
        conv3 = Conv2d(conv3, 256, (3, 3), act=tf.nn.relu, name='conv3_2')
        conv3 = Conv2d(conv3, 256, (3, 3), act=tf.nn.relu, name='conv3_3')
        pool3 = MaxPool2d(conv3, (2, 2), name='pool3')
        
        conv4 = Conv2d(pool3, 512, (3, 3), act=tf.nn.relu, name='conv4_1')
        conv4 = Conv2d(conv4, 512, (3, 3), act=tf.nn.relu, name='conv4_2')
        conv4 = Conv2d(conv4, 512, (3, 3), act=tf.nn.relu, name='conv4_3')   
        pool4 = MaxPool2d(conv4, (2, 2), name='pool4')
        
        conv5 = Conv2d(pool4, 512, (3, 3), act=tf.nn.relu, name='conv5_1')
        conv5 = Conv2d(conv5, 512, (3, 3), act=tf.nn.relu, name='conv5_2')
        conv5 = Conv2d(conv5, 512, (3, 3), act=tf.nn.relu, name='conv5_3')

        
        score_dsn1 = Conv2d(conv1, 2, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='score_dsn1')
        
        score_dsn2 = Conv2d(conv2, 1, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='score_dsn2')
        upsample_2 = DeConv2d(score_dsn2, 2, (4, 4), (nx, ny), (2, 2), name='upsample_2')
        
        score_dsn3 = Conv2d(conv3, 1, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='score_dsn3')
        upsample_3 = DeConv2d(score_dsn3, 2, (8, 8), (nx, ny), (4, 4), name='upsample_3')
        
        score_dsn4 = Conv2d(conv4, 1, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='score_dsn4')
        upsample_4 = DeConv2d(score_dsn4, 2, (16, 16), (nx, ny), (8, 8), name='upsample_4')
        
        score_dsn5 = Conv2d(conv5, 1, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='score_dsn5')
        upsample_5 = DeConv2d(score_dsn5, 2, (32, 32), (nx, ny), (16, 16), name='upsample_5')
        
        concatall = ConcatLayer([score_dsn1,upsample_2,upsample_3,upsample_4,upsample_5], 3, name='concatall')
        network = Conv2d(concatall, 2, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='output')
        
        #================Groundtruth==========================
        if is_train:        
            y_back = tf.slice(y_,[0,0,0,0],[batch_size,nx,ny,1])
            y_fore = tf.slice(y_,[0,0,0,1],[batch_size,nx,ny,1])
            w = y_back+y_fore*30
            y_ = tf.reshape(y_,[batch_size*nx*ny,2])
            fw = tf.reshape(w,[batch_size*nx*ny])
                       
            y1 = score_dsn1.outputs   
            y1 = tf.reshape(y1,[batch_size*nx*ny,2])
            y1_prob = tf.nn.softmax(y1)        
            cost1 = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y1_prob+sida),1),fw))
            
            y2 = upsample_2.outputs   
            y2 = tf.reshape(y2,[batch_size*nx*ny,2])
            y2_prob = tf.nn.softmax(y2)        
            cost2 = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y2_prob+sida),1),fw))
            
            y3 = upsample_3.outputs   
            y3 = tf.reshape(y3,[batch_size*nx*ny,2])
            y3_prob = tf.nn.softmax(y3)          
            cost3 = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y3_prob+sida),1),fw))
            
            y4 = upsample_4.outputs   
            y4 = tf.reshape(y4,[batch_size*nx*ny,2])
            y4_prob = tf.nn.softmax(y4)          
            cost4 = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y4_prob+sida),1),fw))
            
            y5 = upsample_5.outputs   
            y5 = tf.reshape(y5,[batch_size*nx*ny,2])
            y5_prob = tf.nn.softmax(y5)          
            cost5 = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y5_prob+sida),1),fw))
            
            y = network.outputs   
            y = tf.reshape(y,[batch_size*nx*ny,2])
            y_prob = tf.nn.softmax(y)
            y_class = tf.argmax(y_prob, 1)
            y_class = tf.reshape(y_class,[batch_size,nx,ny,1])           
            cost_fuse = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y_prob+sida),1),fw))
            
            cost = cost1+cost2+cost3+cost4+cost5+5*cost_fuse
            return network ,cost,y_class
        else:
            y = network.outputs   
            y = tf.reshape(y,[batch_size*nx*ny,2])
            y_prob = tf.nn.softmax(y)
            y_class = tf.argmax(y_prob, 1)
            y_class = tf.reshape(y_class,[batch_size,nx,ny,1])
        
            y_prob = tf.slice(y_prob,[0,1],[batch_size*nx*ny,1])
            y_prob = tf.reshape(y_prob,[batch_size,nx,ny,1])
            return network, y_class, y_prob
	
def model_Unet(x,y_,batch_size, reuse,mean_file_name=None,is_train = True):
    if mean_file_name!=None:
        meanval = np.load(mean_file_name)
        x = image_preprocess(x,meanval)
    _, nx, ny, nz = x.get_shape().as_list()
    sida = 0.000001
    with tf.variable_scope("u_net", reuse=reuse):
        tl.layers.set_name_reuse(reuse)
        inputs = InputLayer(x, name='inputs')
        conv1 = Conv2d(inputs, 64, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='conv1_1')
        conv1 = Conv2d(conv1, 64, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv1_2')
        pool1 = MaxPool2d(conv1, (2, 2), name='pool1')
        conv2 = Conv2d(pool1, 128, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv2_1')
        conv2 = Conv2d(conv2, 128, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv2_2')
        pool2 = MaxPool2d(conv2, (2, 2), name='pool2')
        conv3 = Conv2d(pool2, 256, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv3_1')
        conv3 = Conv2d(conv3, 256, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv3_2')
        pool3 = MaxPool2d(conv3, (2, 2), name='pool3')
        conv4 = Conv2d(pool3, 512, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv4_1')
        conv4 = Conv2d(conv4, 512, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv4_2')
        pool4 = MaxPool2d(conv4, (2, 2), name='pool4')
        conv5 = Conv2d(pool4, 1024, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv5_1')
        conv5 = Conv2d(conv5, 1024, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv5_2')

        up4 = DeConv2d(conv5, 512, (3, 3), (nx/8, ny/8), (2, 2), name='deconv4')
        up4 = ConcatLayer([up4, conv4], 3, name='concat4')
        conv4 = Conv2d(up4, 512, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv4_1')
        conv4 = Conv2d(conv4, 512, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv4_2')
        up3 = DeConv2d(conv4, 256, (3, 3), (nx/4, ny/4), (2, 2), name='deconv3')
        up3 = ConcatLayer([up3, conv3], 3, name='concat3')
        conv3 = Conv2d(up3, 256, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv3_1')
        conv3 = Conv2d(conv3, 256, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='uconv3_2')
        up2 = DeConv2d(conv3, 128, (3, 3), (nx/2, ny/2), (2, 2), name='deconv2')
        up2 = ConcatLayer([up2, conv2], 3, name='concat2')
        conv2 = Conv2d(up2, 128, (3, 3), act=tf.nn.relu,  W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv2_1')
        conv2 = Conv2d(conv2, 128, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv2_2')
        up1 = DeConv2d(conv2, 64, (3, 3), (nx/1, ny/1), (2, 2), name='deconv1')
        up1 = ConcatLayer([up1, conv1] , 3, name='concat1')
        conv1 = Conv2d(up1, 64, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv1_1')
        conv1 = Conv2d(conv1, 64, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv1_2')
        network = Conv2d(conv1, 2, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv1')
        
        #================Groundtruth==========================
        if is_train: 
            y_back = tf.slice(y_,[0,0,0,0],[batch_size,nx,ny,1])
            y_fore = tf.slice(y_,[0,0,0,1],[batch_size,nx,ny,1])
            w = y_back+y_fore*30
            y_ = tf.reshape(y_,[batch_size*nx*ny,2])
            w = tf.reshape(w,[batch_size*nx*ny])
            
            y = network.outputs   
            y = tf.reshape(y,[batch_size*nx*ny,2])
            y_prob = tf.nn.softmax(y)
            y_class = tf.argmax(y_prob, 1)
            y_class = tf.reshape(y_class,[batch_size,nx,ny,1])
            
            cost = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y_prob+sida),1),w))
            return network, cost, y_class
            
        else:
            y = network.outputs   
            y = tf.reshape(y,[batch_size*nx*ny,2])
            y_prob = tf.nn.softmax(y)
            y_class = tf.argmax(y_prob, 1)
            y_class = tf.reshape(y_class,[batch_size,nx,ny,1])
        
            y_prob = tf.slice(y_prob,[0,1],[batch_size*nx*ny,1])
            y_prob = tf.reshape(y_prob,[batch_size,nx,ny,1])
            return network, y_class, y_prob
            
            
def model_Unet_PW(x,y_,batch_size,data_shape, reuse,mean_file_name=None,is_train = True):
    if mean_file_name!=None:
        meanval = np.load(mean_file_name)
        x = image_preprocess(x,meanval)
    _, nx, ny, nz = x.get_shape().as_list()
    sida = 0.000001
    drop_rate = 0.8
    with tf.variable_scope("u_net_pw", reuse=reuse):
        tl.layers.set_name_reuse(reuse)
        inputs = InputLayer(x, name='inputs')
        conv1 = Conv2d(inputs, 64, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='conv1_1')
        conv1 = Conv2d(conv1, 64, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv1_2')
        pool1 = MaxPool2d(conv1, (2, 2), name='pool1')
        conv2 = Conv2d(pool1, 128, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv2_1')
        conv2 = Conv2d(conv2, 128, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv2_2')
        pool2 = MaxPool2d(conv2, (2, 2), name='pool2')
        conv3 = Conv2d(pool2, 256, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv3_1')
        conv3 = Conv2d(conv3, 256, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv3_2')
        pool3 = MaxPool2d(conv3, (2, 2), name='pool3')
        conv4 = Conv2d(pool3, 512, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv4_1')
        conv4 = Conv2d(conv4, 512, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv4_2')
        pool4 = MaxPool2d(conv4, (2, 2), name='pool4')
        conv5 = Conv2d(pool4, 1024, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv5_1')
        conv5 = Conv2d(conv5, 1024, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='conv5_2')

        up4 = DeConv2d(conv5, 512, (3, 3), (nx/8, ny/8), (2, 2), name='deconv4')
        up4 = ConcatLayer([up4, conv4], 3, name='concat4')
        conv4 = Conv2d(up4, 512, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv4_1')
        conv4 = Conv2d(conv4, 512, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv4_2')
        up3 = DeConv2d(conv4, 256, (3, 3), (nx/4, ny/4), (2, 2), name='deconv3')
        up3 = ConcatLayer([up3, conv3], 3, name='concat3')
        conv3 = Conv2d(up3, 256, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv3_1')
        conv3 = Conv2d(conv3, 256, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0), name='uconv3_2')
        up2 = DeConv2d(conv3, 128, (3, 3), (nx/2, ny/2), (2, 2), name='deconv2')
        up2 = ConcatLayer([up2, conv2], 3, name='concat2')
        conv2 = Conv2d(up2, 128, (3, 3), act=tf.nn.relu,  W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv2_1')
        conv2 = Conv2d(conv2, 128, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv2_2')
        up1 = DeConv2d(conv2, 64, (3, 3), (nx/1, ny/1), (2, 2), name='deconv1')
        up1 = ConcatLayer([up1, conv1] , 3, name='concat1')
        conv1 = Conv2d(up1, 64, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv1_1')
        conv1 = Conv2d(conv1, 64, (3, 3), act=tf.nn.relu, W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),name='uconv1_2')
#        network = Conv2d(conv1, 2, (1, 1), W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
#                   b_init = tf.constant_initializer(value=0.0),name='uconv1')

        """## cost of classification3"""
        network1_up = tl.layers.DropoutLayer(conv1,keep=drop_rate,is_train=is_train,name='up1')
        network_class3 = tl.layers.Conv2dLayer(network1_up,             
               shape = [3, 3, 64, 64], # 64 features for each 5x5 patch
               strides=[1, 1, 1, 1],
               padding='SAME',
               W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
               b_init = tf.constant_initializer(value=0.0),
               name ='score1_feaconv')  # output: (?, 14, 14, 64)
        network_class3 = tl.layers.DropoutLayer(network_class3,keep=drop_rate,is_train=is_train,name='drop3')
        network_class3 = tl.layers.Conv2dLayer(network_class3,             
               shape = [3, 3, 64, 2], # 64 features for each 5x5 patch
               strides=[1, 1, 1, 1],
               padding='SAME',
               W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
               b_init = tf.constant_initializer(value=0.0),
               name ='output1')  # output: (?, 14, 14, 64)
        if is_train:
            """## cost of classification2"""
            network2_up = tl.layers.DropoutLayer(conv2,keep=drop_rate,is_train=is_train,name='up2')
            network_class2 = tl.layers.Conv2dLayer(network2_up,             
                   shape = [3, 3, 128, 64], # 64 features for each 5x5 patch
                   strides=[1, 1, 1, 1],
                   padding='SAME',
                   W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),
                   name ='score2_feaconv')  # output: (?, 14, 14, 64)
            network_class2 = tl.layers.DropoutLayer(network_class2,keep=drop_rate,is_train=is_train,name='drop2')
            network_class2 = tl.layers.Conv2dLayer(network_class2,             
                   shape = [3, 3, 64, 2], # 64 features for each 5x5 patch
                   strides=[1, 1, 1, 1],
                   padding='SAME',
                   W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),
                   name ='score2_cmb1')  # output: (?, 14, 14, 64)
            network_class2 =tl.layers.UpSampling2dLayer(network_class2,
                   size = [data_shape[0],data_shape[1]],
                   method =0,
                   is_scale = False,
                   name = 'output2' )
            
            """## cost of classification1"""
            network3_up = tl.layers.DropoutLayer(conv3,keep=drop_rate,is_train=is_train,name='up3')
            network_class1 = tl.layers.Conv2dLayer(network3_up,             
                   shape = [3, 3, 256, 128], # 64 features for each 5x5 patch
                   strides=[1, 1, 1, 1],
                   padding='SAME',
                   W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),
                   name ='score3_feaconv')  # output: (?, 14, 14, 64)
            network_class1 = tl.layers.DropoutLayer(network_class1,keep=drop_rate,is_train=is_train,name='drop1')
            network_class1 = tl.layers.Conv2dLayer(network_class1,             
                   shape = [3, 3, 128, 2], # 64 features for each 5x5 patch
                   strides=[1, 1, 1, 1],
                   padding='SAME',
                   W_init=tf.contrib.layers.xavier_initializer_conv2d(uniform=True, seed=None, dtype=tf.float32),
                   b_init = tf.constant_initializer(value=0.0),
                   name ='score3_cmb2')  # output: (?, 14, 14, 64)
            network_class1 =tl.layers.UpSampling2dLayer(network_class1,
                   size = [data_shape[0],data_shape[1]],
                   method =0,
                   is_scale = False,
                   name = 'output3' )
            
            ## merge all classification
            network_final = Mergelayer([network_class1,network_class2,network_class3],
                   name = 'mergeall'               )
                    
            #================Groundtruth==========================
            y_ = tf.reshape(y_,[batch_size*data_shape[0]*data_shape[1],2])
            w1 = tf.ones([batch_size*data_shape[0]*data_shape[1]])
    
            #================cost1================================
            y1 = network_class1.outputs   
            y1 = tf.reshape(y1,[batch_size*data_shape[0]*data_shape[1],2])
            y1_prob = tf.nn.softmax(y1)
            y1_class = tf.argmax(y1_prob, 1)
            crect_pred1 = tf.equal(y1_class, tf.argmax(y_,1)) 
            crect_pred1 = tf.cast(crect_pred1, "float")
            y1_class = tf.reshape(y1_class,[batch_size,data_shape[0],data_shape[1],1])
            
            cost1 = -tf.reduce_mean(tf.reduce_sum(y_*tf.log(y1_prob+sida),1))
        
            #================cost2================================
            acc1 = tf.reduce_mean(crect_pred1)
            alpha1 = -1.5*tf.log(acc1)
            w2 = tf.multiply(w1,tf.exp((0.5-crect_pred1)*2*alpha1))
            w2 = w2*data_shape[0]*data_shape[1]*batch_size/tf.reduce_sum(w2)
    
            y2 = network_class2.outputs   
            y2 = tf.reshape(y2,[batch_size*data_shape[0]*data_shape[1],2])
            y2_prob = tf.nn.softmax(y2)
            y2_class = tf.argmax(y2_prob, 1)
            crect_pred2 = tf.equal(y2_class, tf.argmax(y_,1)) 
            crect_pred2 = tf.cast(crect_pred2, "float")
            y2_class = tf.reshape(y2_class,[batch_size,data_shape[0],data_shape[1],1])
            
            cost2 = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y2_prob+sida),1),w2))
            
            #================cost3================================
            acc2 = tf.reduce_mean(crect_pred2)
            alpha2 = -1.5*tf.log(acc2)
            w3 = tf.multiply(w2,tf.exp((0.5-crect_pred2)*2*alpha2))
            w3 = w3*data_shape[0]*data_shape[1]*batch_size/tf.reduce_sum(w3)
    
            y3 = network_class3.outputs   
            y3 = tf.reshape(y3,[batch_size*data_shape[0]*data_shape[1],2])
            y3_prob = tf.nn.softmax(y3)
            y3_class = tf.argmax(y3_prob, 1)
            y3_class = tf.reshape(y3_class,[batch_size,data_shape[0],data_shape[1],1])
 
            
            cost3 = -tf.reduce_mean(tf.multiply(tf.reduce_sum(y_*tf.log(y3_prob+sida),1),w3))
            cost = cost1+cost2+cost3
            #================costall================================
            return network_final,cost,y3_class
        else:
            y3 = network_class3.outputs  
#            phi = tf.slice(y3,[0,0,0,1],[batch_size,data_shape[0],data_shape[1],1])
            y3 = tf.reshape(y3,[batch_size*data_shape[0]*data_shape[1],2])
            y3_prob = tf.nn.softmax(y3)
            y3_class = tf.argmax(y3_prob, 1)
            y_final_class = tf.reshape(y3_class,[batch_size, data_shape[0],data_shape[1],1])
            
            y_final_prob = tf.slice(y3_prob,[0,1],[batch_size*data_shape[0]*data_shape[1],1])
            y_final_prob = tf.reshape(y_final_prob,[batch_size, data_shape[0],data_shape[1],1])
            return network_class3,y_final_class,y_final_prob    