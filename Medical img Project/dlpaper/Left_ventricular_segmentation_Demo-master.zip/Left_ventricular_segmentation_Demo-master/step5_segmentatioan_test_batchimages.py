# -*- coding: utf-8 -*-
"""
Created on Tue Feb  6 16:17:53 2018

@author: Xie Lipeng
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Jan 13 14:00:43 2018

@author: dlwork
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 14 16:29:01 2017

@author: XLP
"""

import numpy as np
from utils.write_read_tfrecord import *
import tensorflow as tf
import tensorlayer as tl 
from PIL import Image
import matplotlib.pyplot as plt
import glob
import scipy.misc
import os
import time
from nets.construct_model import *
 
    
def Dice_Jaccard_ND(G,S):
    GS_Inter = G & S
    GS_Inter = np.sum(GS_Inter)
    GS_Union = G | S
    GS_Union = np.sum(GS_Union)

    G = np.sum(G)
    S = np.sum(S)
    Dice = 2*GS_Inter/(G+S)
    Jaccard  = GS_Inter/GS_Union               
    return Dice, Jaccard
    
def Pixel_evalution_ND(G,S):
    T1 = np.sum(G&S)  
    T0 = np.sum(np.logical_not(G)&np.logical_not(S)) 
    P = T1/np.sum(G)
    Q = T0/np.sum(np.logical_not(G))
    PPV = T1/(np.sum(S)+0.00001)
    NPV = T0/np.sum(np.logical_not(S))
    return P,Q,PPV,NPV


#=========================step1: Set parameters===============================
netname = 'Unet_PW' #'Fcn8s','Hed','Unet','Proposed_Without_PW','Proposed'
model_name = "model_tfrecord.ckpt"

#==============================================================================
model_path = './checkpoints/'+netname+'/'
save_path = './outputs/'+netname+'/'
datapath = './data/'  #the path to store patches and lmdb
datapath_images = './data/testing-set/'
if not os.path.exists(save_path):
    os.mkdir(save_path)
#patchpathlist = glob.glob(datapath+'patches_'+'*')
model_file_name = model_path + model_name
mean_file_name = './data/train_1_1.tfrecords_mean.npy'
option_resume = True # load model, resume from previous checkpoint?

batch_size = 1
data_shape = [256,256,1]
mean_file_name = './data/train_1_1.tfrecords_mean.npy'
is_train = False
reuse= False
#=========================step3: Creat network===============================
# Define the batchsize at the begin, you can give the batchsize in x and y_

x = tf.placeholder(tf.float32, shape=[batch_size,data_shape[0],data_shape[1],data_shape[2]])   # [batch_size, height, width, channels]
y_ = tf.placeholder(tf.float32, shape=[batch_size,data_shape[0],data_shape[1], 2])

if netname=='Proposed' or netname=='Proposed_Without_PW'or netname=='Unet_PW':
    exec('network_predict,op_class,_ = model_'+netname+'(x, y_, batch_size, data_shape, reuse=reuse, mean_file_name=mean_file_name,is_train = is_train)')
else:
    exec('[network_predict,op_class,_] = model_'+netname+'(x,y_,batch_size,reuse=reuse,mean_file_name=mean_file_name, is_train = is_train)')
    

sess = tf.Session()
init = tf.initialize_all_variables()  
sess.run(init)
print("Load existing model " + "!"*10)
saver = tf.train.Saver(network_predict.all_params)
saver.restore(sess, model_file_name)

#=========================step4: Load image===============================

Num_img = 0
Dice_acc_list = []
Jaccard_list = []
P_list = []
Q_list = []
PPV_list = []
NPV_list = []
Imagelist = glob.glob("%s*_mask.png" %(datapath_images))
np.save('./Imagelist',Imagelist)
start_time = time.time()
for imgmaskname in sorted(Imagelist):
    imgpathname = imgmaskname[:-9]
    imgname = imgmaskname.split('\\')[1]
    imgname = imgname[:-9]
    image = Image.open(imgpathname+'.png')
    img_shape = image.size
    img_ori = np.array(image)
    if img_shape[0]!=data_shape[0] or img_shape[1]!=data_shape[1]:
        Flag_imgreshape = True
        image = image.resize((data_shape[0],data_shape[1]))
    else:
        Flag_imgreshape = False
    image = np.array(image)
    image = image[np.newaxis,:,:,np.newaxis]
    feed_dict = {x: image}
    prediction_class_out= sess.run(op_class, feed_dict=feed_dict) 
    prediction_class = prediction_class_out[0,:,:,0]
   
    if Flag_imgreshape:     
        prediction_class= Image.fromarray(np.uint8(prediction_class))
        prediction_class= prediction_class.resize(img_shape)
        prediction_class= np.int64(np.array(prediction_class))
        
        
        rgb = np.zeros((img_shape[1], img_shape[0], 3), dtype=np.uint8)
        rgb[..., 0] = (prediction_class==0)*img_ori+prediction_class*255
        rgb[..., 1] = (prediction_class==0)*img_ori
        rgb[..., 2] = (prediction_class==0)*img_ori
        scipy.misc.imsave(save_path +imgname +'_result.png',rgb)
    else:
        
        rgb = np.zeros((img_shape[1], img_shape[0], 3), dtype=np.uint8)
        rgb[..., 0] = (prediction_class==0)*img_ori+prediction_class*255
        rgb[..., 1] = (prediction_class==0)*img_ori
        rgb[..., 2] = (prediction_class==0)*img_ori
        scipy.misc.imsave(save_path +imgname +'_result.png',rgb)
    
    Mask = Image.open(imgpathname+'_mask.png')
    Mask = np.array(Mask.convert('L'),'uint8')>0
    Seg = prediction_class>0
   
    D,J = Dice_Jaccard_ND(Mask,Seg)
    Dice_acc_list.append(D)
    Jaccard_list.append(J)
    
    P,Q,PPV,NPV = Pixel_evalution_ND(Mask,Seg)
    P_list.append(P)
    Q_list.append(Q)
    PPV_list.append(PPV)
    NPV_list.append(NPV)
    Num_img = Num_img + 1

    
totaltime = time.time() - start_time
print(" Mean time: %f" % (totaltime/Num_img))    
np.save('./Meantime_'+netname,(totaltime/Num_img))    

Dice_acc = np.array(Dice_acc_list)
Mean_Dice_acc = np.sum(Dice_acc)/Num_img
print(" Test Dice acc: %f" % (Mean_Dice_acc))


np.save('./Evaluation_'+netname,[Dice_acc_list,Jaccard_list,P_list,Q_list,PPV_list,NPV_list])

fig = plt.figure(1, figsize=(10, 8))
ax = fig.add_subplot(111)
bp = ax.boxplot([Dice_acc_list,Jaccard_list,P_list,Q_list,PPV_list,NPV_list])
ax.set_xticklabels(['Dice', 'Jaccard','Sensitivity','Specificity', 'PPV', 'NPV'])
ax.get_xaxis().tick_bottom()
ax.get_yaxis().tick_left()
fig.savefig('CNN_Cradic_Seg_Performance_Proposed.png', bbox_inches='tight')


#=========================step4: Train network===============================
sess.close()